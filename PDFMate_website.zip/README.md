# PDFMate
A simple iLovePDF-style PDF website with two working tools:
1. Open PDF — preview PDF pages in the browser.
2. Merge PDF — select multiple PDFs, arrange/remove files, merge and download.

## Run
Just open `index.html` in a modern browser. Internet is required because PDF.js, pdf-lib and Google Fonts are loaded from CDNs.

## Free hosting
Upload `index.html` to GitHub Pages, Netlify, or Vercel. No backend is required for these two features; PDF processing happens in the browser.
